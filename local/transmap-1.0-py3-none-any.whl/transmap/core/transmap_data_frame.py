import contextily as ctx
from geopandas import GeoDataFrame
from .domain import DatasetInformation, Basemaps


class TransMAPDataFrame(GeoDataFrame):
    """
    Extends the geopandas GeoDataFrame, to keep metadata and allow for quick map display.

    Attributes
    ----------
    metadata : [DatasetInformation, None]
        Metadata associated with the dataset.
    row_count: int
        A count of all the records in the dataset.
    column_count: int
        A count of all the fields in the dataset.

    Methods
    -------
    set_dataset_information(dataset_information: DatasetInformation, crs=None)
        Add metadata and spatial reference information to the dataset.

    map(size: tuple = None, transparency: float = None)
        Create a simple map of the dataset records.
    """
    metadata: [DatasetInformation, None]
    __web_mercator = 3857

    def __init__(self, data=None, *args, geometry=None, crs=None,
                 **kwargs):
        super().__init__(data=data, *args, geometry=geometry, crs=None, **kwargs)
        self.metadata = None

    @property
    def row_count(self):
        """
        Returns
        -------
        int
            A count of all the records in the dataset
        """
        return self.shape[0]

    @property
    def column_count(self):
        """
        Returns
        -------
        int
            A count of all the fields in the dataset
        """
        return self.shape[1]

    def set_dataset_information(self, dataset_information: DatasetInformation):
        """
        Parameters
        ----------
            :param dataset_information: DatasetInformation
                Dataset metadata.
        """
        self.metadata = dataset_information
        self.crs = dataset_information.extents.spatial.crs

    def map(self, size: tuple = None, transparency: float = None):
        """
        Parameters
        ----------
            :param transparency: float
                Transparency of the features.
            :param size: tuple
                Height and Width of the output.
        """
        web_mercator_data = self.to_crs(epsg=self.__web_mercator)
        map_view = web_mercator_data.plot(figsize=size, alpha=transparency)
        ctx.add_basemap(map_view)
