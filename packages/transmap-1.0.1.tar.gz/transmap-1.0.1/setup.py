# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['transmap',
 'transmap.client',
 'transmap.core',
 'transmap.tests',
 'transmap.tests.client',
 'transmap.tests.core']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'transmap',
    'version': '1.0.1',
    'description': '',
    'long_description': 'None',
    'author': 'Hayley Hames',
    'author_email': 'hhames@uark.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9',
}


setup(**setup_kwargs)
