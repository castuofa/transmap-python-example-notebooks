from typing import Dict, List

from result import Result, Err, Ok

from .domain import DataCategory, DatasetInformation
from ..client.web_client import WebClient
from .transmap_data_frame import TransMAPDataFrame


class TransMAP:
    """
    A class that interacts with the TransMAP web api.

    """
    __client: WebClient

    __post_headers: Dict[str, str] = {
        'Content-type': 'application/json-patch+json',
        'Accept': 'text/plain'
    }

    def __init__(self, transmap_uri: str):
        """
        Parameters
        ----------
        :param transmap_uri : str
            The URI to the current transmap web API. Please see the TransMAP website for the current URI
        """
        self.__client = WebClient(transmap_uri, self.__post_headers)

    def categories(self) -> List[DataCategory]:
        """Lists  all data categories of current TransMap resources.

        Returns
        -------
        List[DataCategory]
            A list of category summary information.
        """

        response = self.__client.get('categories')
        categories = []
        for category in response.json():
            categories.append(DataCategory.parse_obj(category))
        return categories

    def search(self, search_text: str, categories: List[DataCategory] = None) -> List[DatasetInformation]:
        """ Search for data registered with TransMAP.
        Parameters
        ----------
            :param search_text: str
                Text to use for searching data
            :param categories: List[DataCategory]
                List of DataCategory objects to limit the text search results. (Default = None)

        Returns
        -------
        List[DatasetInformation]
            A list of dataset metadata matching the search criteria.
        """
        post_parameters = {
            "searchCriteria": {
                "layertype": "Vector",
                "text": search_text,
            },
            "sort": "title_asc",
            "limit": 0,
            "offset": 0
        }

        # Add categories if they are present.
        if categories is not None and len(categories) > 0:
            category_list = []
            for category in categories:
                category_list.append(category.identifier)
            post_parameters["searchCriteria"]["categories"] = category_list

        response = self.__client.post('Layers', post_parameters).json()
        layers = []
        for layer in response['items']:
            layers.append(DatasetInformation.parse_obj(layer))
        return layers

    def get_dataset_info(self, dataset_id: str):
        """ Retrieve metadata for a known dataset.
        Parameters
        ----------
            :param dataset_id: str
                ID of the dataset.

        Returns
        -------
        DatasetInformation
            Metadata for the specified dataset.
        """
        return DatasetInformation.parse_obj(self.__client.get(f'layers/{dataset_id}').json())

    def __get_json_data__(self, post_parameters) -> Result[List[object],str]:
        response = self.__client.post('Data/GetDataById', post_parameters).json()
        features = response['data']['features']
        if len(features) > 0:
            return Ok(features)
        return Err(f"No data returned for {post_parameters['id']}.")

    # TODO: if id is not provided, throw error
    # TODO: if bounding_box is not a list of floats throw error
    def fetch(self, dataset: DatasetInformation = None, dataset_id: str = None,
              bounding_box: List[float] = None,
              start_date: str = None,
              end_date: str = None, record_limit: int = 50000) -> TransMAPDataFrame:
        """ Fetch the data from a TransMAP dataset.

        Parameters
        ----------
            :param record_limit: int
                Limits number of records return. (default is 50,000)
            :param end_date: str
                End date of the data request Format example: "8/31/2003 12:00:00 AM" (default is none)
            :param start_date: str
                Start date of the data request Format example: "8/31/2003 12:00:00 AM" (default is none)
            :param bounding_box: List[float]
                A bounding box for the dataset area. Format: [xmin, ymin, xmax, ymax] (default is none)
            :param dataset_id: str
                ID of the dataset. Either dataset_id or dataset must be provided. (default is none)
            :param dataset: DatasetInformation
                Metadata of the dataset. Either dataset_id or dataset must be provided. (default is none)

        Returns
        -------
        TransMAPDataFrame
            A spatially enabled DataFrame with built-in metadata and mapping capabilities.
        """
        print("Fetching data... be patient, large datasets may take several minutes.")
        post_parameters = {
            'id': dataset_id if dataset_id is not None else dataset.id,
            'bbox': [] if bounding_box is None else bounding_box,
            'offset': 0
        }

        if start_date is not None and end_date is not None:
            post_parameters['startDate'] = start_date
            post_parameters['endDate'] = end_date

        json_features_result = self.__get_json_data__(post_parameters)

        if json_features_result.is_err():
            print(json_features_result.err())
            return TransMAPDataFrame()

        # Get the rest of the data if there is more.
        raw_dataset: List[object] = json_features_result.ok()
        while json_features_result.is_ok() and len(raw_dataset) < record_limit:
            # Fetch more data
            post_parameters['offset'] = post_parameters['offset'] + len(json_features_result.ok())
            data_result = self.__get_json_data__(post_parameters)

            if data_result.err():
                # Fetch returned no data, assume end of dataset.
                break

            raw_dataset.extend(json_features_result.ok())

        dataset_information = dataset if dataset is not None else self.get_dataset_info(dataset_id)
        transmap_data_frame = TransMAPDataFrame.from_features(raw_dataset[0:record_limit])
        transmap_data_frame.set_dataset_information(dataset_information=dataset_information)
        return transmap_data_frame
