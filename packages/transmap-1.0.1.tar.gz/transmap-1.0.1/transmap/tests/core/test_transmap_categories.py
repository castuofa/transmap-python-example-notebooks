import pytest
import requests
import requests_mock

import transmap.client.web_client
from transmap.core.transmap import TransMAP
from requests import Response


@pytest.fixture(scope='function')
def mock_response():
    test_url = 'https://placeholder'
    test_json = {'name': 'John', 'age': 30, 'car': None}
    request_object = requests_mock.get(test_url, json=test_json, status_code=404)
    res = requests.get(test_url)
    return res


def test_outer_function(mocker, mock_response):
    mocker.patch(
        'transmap.client.web_client.WebClient.get',
        return_value=mock_response
    )
    transmap_uri = 'https://oak.cast.uark.edu/metadata-api'
    sut = TransMAP(transmap_uri)

    actual = sut.categories()
    assert actual.status_code == mock_response.status_code
    assert actual.json() == mock_response.json()


def test_transmap_should_return_categories():
    transmap_uri = 'https://oak.cast.uark.edu/metadata-api'
    sut = TransMAP(transmap_uri)
    assert sut.get_base_uri() == transmap_uri
