import pytest
from transmap.client.web_client import WebClient
from requests.exceptions import InvalidURL


def test_web_client_should_create_with_valid_uri():
    transmap_uri = 'https://oak.cast.uark.edu/metadata-api'
    sut = WebClient(transmap_uri)
    assert sut.get_base_uri() == transmap_uri


def test_web_client_should_raise_error_with_invalid_uri():
    with pytest.raises(InvalidURL):
        WebClient('google')


def test_web_client_should_drop_ending_forward_slash_from_base_uri():
    sut = WebClient('http://www.google.com/')
    assert sut.get_base_uri() == 'http://www.google.com'
