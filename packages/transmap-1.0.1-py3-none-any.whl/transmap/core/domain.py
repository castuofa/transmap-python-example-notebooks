from datetime import datetime
from enum import Enum
from typing import List, Dict, Optional

from pydantic import Field
from pydantic.main import BaseModel


class Basemaps(Enum):
    OpenStreetMap = "OpenStreetMap"
    StamenTerrain = "Stamen Terrain"
    StamenToner = "Stamen Toner"
    StamenWatercolor = "Stamen Watercolor"
    CartoDbDark = "CartoDB dark_matter"
    CartoDbPositron = "CartoDB positron"


class DataCategory(BaseModel):
    class Config:
        arbitrary_types_allowed = True
        allow_population_by_field_name = True

    name: str = Field(alias="gn_description")
    identifier: str
    description: str
    name: str
    count: int


class SpatialExtentsMetadata(BaseModel):
    bbox: Optional[List[int]]
    crs: Optional[str]
    center: Optional[List[int]]
    minzoom: Optional[int]
    maxzoom: Optional[int]


class TemporalExtentsMetadata(BaseModel):
    begin: Optional[datetime]
    end: Optional[datetime]


class ExtentsMetadata(BaseModel):
    spatial: SpatialExtentsMetadata
    temporal: TemporalExtentsMetadata


class RequiredParameter(BaseModel):
    type: str
    hidden: str
    description: str
    defaultValue: str
    valueOptions: List[str]


class DataAttribute(BaseModel):
    type: str
    alias: str
    description: Optional[str]
    example: Optional[str]


class Publisher(BaseModel):
    type: str
    name: str
    subOrganizationOf: str


class DatasetInformation(BaseModel):
    layer_type: str
    extents: ExtentsMetadata
    geometry_type: str
    required_parameters: Dict[str, RequiredParameter]
    data_attributes: Dict[str, DataAttribute]
    # associated_resources: List[str]
    id: str
    title: str
    description: str
    abstract: str
    categories: List[str]
    resource_type: str
    created: datetime
    last_update: datetime
    publisher: Publisher
