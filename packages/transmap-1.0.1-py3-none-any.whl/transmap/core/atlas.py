from keplergl import KeplerGl
from typing import Dict
from .transmap_data_frame import TransMAPDataFrame


class Atlas:
    """ A Class for working with TransMAP DataFrames and KeplerGL mapping library
    Methods
    -------
    add_dataset(dataset: TransMAPDataFrame)
        Add a dataset to the Atlas catalog.

    remove_dataset(dataset: TransMAPDataFrame = None, dataset_id: str = None, title: str = None)
        Remove a dataset from the Atlas catalog.

    clear_catalog()
        Removes all datasets from the Atlas catalog.

    map(height: int = 400)
        Create a Kepler.Gl map object of the current catalog.
    """
    __catalog: Dict[str, TransMAPDataFrame]

    def __init__(self) -> None:
        """
         Create a new Atlas instance.
         """
        self.__catalog = dict()

    def add_dataset(self, dataset: TransMAPDataFrame):
        """ Add a dataset to the Atlas catalog.
       Parameters
       ----------
           :param dataset: TransMAPDataFrame
                Dataset to be added to the catalog
       """
        if dataset.metadata.title not in self.__catalog.keys():
            self.__catalog[dataset.metadata.title] = dataset

    def remove_dataset(self, dataset: TransMAPDataFrame = None, dataset_id: str = None, title: str = None):
        """ Remove a dataset from the Atlas catalog, by supplying a dataset, id, or title.

       Parameters
       ----------
           :param title:
                Title of dataset to be removed from the catalog (default = None)
           :param dataset_id:
                ID of dataset to be removed from the catalog (default = None)
           :param dataset: TransMAPDataFrame
                Dataset to be removed from the catalog (default = None)
       """
        if dataset is not None:
            del self.__catalog[dataset.metadata.title]
            return
        if dataset_id is not None:
            for catalog_dataset in self.__catalog.values():
                if catalog_dataset.metadata.id == dataset_id:
                    del self.__catalog[catalog_dataset.metadata.title]
                    return
        if title is not None:
            del self.__catalog[title]

    def clear_catalog(self):
        """Remove all datasets from the Atlas catalog."""
        self.__catalog = dict()

    def map(self, height: int = 400):
        """ Create a Kepler.Gl map object of the current catalog.

      Parameters
      ----------
          :param height: int
            Desired height of the map object.
      """
        return KeplerGl(height=height, data=self.__catalog)
