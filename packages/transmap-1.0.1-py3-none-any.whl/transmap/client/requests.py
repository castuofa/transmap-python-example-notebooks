class LayerSearchRequest:
    def __init__(self, layer_type: str = 'Vector', search_text: str = None, sort: str = 'title_asc', limit: int = 0,
                 offset: int = 0):
        self.searchCriteria = {
            'layertype': layer_type,
            'text': search_text,
            'categories': [],
            'keywords': [],
            'timeEnabledOnly': False
        }
        self.sort = sort
        self.limit = limit
        self.offset = offset
