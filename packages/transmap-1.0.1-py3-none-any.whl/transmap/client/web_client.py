import validators
from requests import get, post, exceptions, Response

from typing import Dict, List, Any


class WebClient:
    __post_headers: Dict[str, str]

    def __init__(self, base_url: str, post_headers=None):
        if not validators.url(base_url):
            raise exceptions.InvalidURL(f'Invalid uri provided: {base_url}')
        else:
            if base_url.endswith('/'):
                base_url = base_url[:-1]
            self.__base_url = base_url
            self.__post_headers = post_headers if post_headers is not None else {}

    def get(self, relative_path: str, params: Dict[str, Any] = None) -> Response:
        response = get(f'{self.__base_url}/{relative_path}', params)
        return response

    def post(self, relative_path: str, params: Dict[str, Any] = None) -> Response:
        response = post(f'{self.__base_url}/{relative_path}', json=params, headers=self.__post_headers)
        response.raise_for_status()
        return response

    def get_base_uri(self):
        return self.__base_url
