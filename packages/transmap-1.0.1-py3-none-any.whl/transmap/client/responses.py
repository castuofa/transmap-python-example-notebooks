from pydantic.class_validators import List
from pydantic.main import BaseModel

from transmap.core.domain import DatasetInformation, DataCategory


class LayerResponse(BaseModel):
  items: List[DatasetInformation]
  total: int
  limit: int
  offset: int
  categories: List[DataCategory]
